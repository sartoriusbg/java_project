
import bg.sofia.uni.fmi.mjt.passwordvault.server.ServerStarter;


import javax.crypto.*;
import java.net.URISyntaxException;
import java.security.*;


public class Main {
    public static void main(String[] args) {
        ServerStarter.start();

    }
}