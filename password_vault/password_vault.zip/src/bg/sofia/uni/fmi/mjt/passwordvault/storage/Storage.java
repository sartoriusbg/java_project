package bg.sofia.uni.fmi.mjt.passwordvault.storage;

import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;

public interface Storage extends InMemoryStorage {

}
